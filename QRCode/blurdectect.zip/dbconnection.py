import this
import mysql.connector
from jproperties import Properties

class Database(object):

   def __init__(self):
        configs = Properties()
  
        with open('qrutil.properties', 'rb') as read_prop:
                configs.load(read_prop)
        hostname = configs.get("HOST").data
        username= configs.get("USER").data
        dbpassword= configs.get("PASSWORD").data
        databasename=configs.get("DATABASE").data

        self._conn = mysql.connector.connect(host=hostname, user=username, password=dbpassword, database=databasename)
        self._cursor = self._conn.cursor()
         

   def __enter__(self):
        return self

   def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()

   @property
   def connection(self):
        return self._conn

   @property
   def cursor(self):
        return self._cursor

   def commit(self):
        self.connection.commit()

   def close(self, commit=True):
        if commit:
            self.commit()
        self._connection.close()

   def execute(self, sql, params=None):
        self._cursor.execute(sql, params or ())

   def fetchall(self):
        return self._cursor.fetchall()

   def fetchone(self):
        return self._cursor.fetchone()

   def query(self, sql, params=None):
        self._cursor.execute(sql, params or ())
        #return self.fetchall()
   